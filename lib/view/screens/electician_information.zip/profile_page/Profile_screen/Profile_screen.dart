import 'package:flutter/material.dart';
import 'package:x_station_app/view/screens/profile_page/Profile_widget/Profile_widget/Profile_widget.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
        body: SingleChildScrollView(
      physics: BouncingScrollPhysics(),
      child: ProfileWidget(),
    ));
  }
}
