import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:x_station_app/core/assets_manager/assets_manager.dart';
import 'package:x_station_app/core/style_font_manager/style_manager.dart';
import 'package:x_station_app/core/text_manager/text_manager.dart';

class Upload extends StatelessWidget {
  const Upload({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 9, top: 24),
          child: SvgPicture.asset(
            AssetsImage.upload,
            width: 161.w,
            height: 196.h,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 11),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 44.h,
              ),
              Text(
                TextManager.AbanoubMaged,
                style: TextStyleManager.textStyleRopotow600,
              ),
              SizedBox(
                height: 10.h,
              ),
              Text(
                TextManager.Twentyone,
                style: TextStyleManager.textStyleRopotow600,
              ),
              SizedBox(
                height: 20.h,
              ),
              Text(
                TextManager.Hourlyrate,
                style: TextStyleManager.textStyleRopotow600,
              ),
              SizedBox(
                height: 10.h,
              ),
              Text(
                TextManager.Rate,
                style: TextStyleManager.textStyleRopotow600,
              ),
              const Padding(
                padding: EdgeInsets.only(
                  left: 137,
                ),
                child: Text(
                  '4.5',
                  style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}
