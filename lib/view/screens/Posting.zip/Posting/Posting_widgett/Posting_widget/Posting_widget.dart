import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:x_station_app/core/assets_manager/assets_manager.dart';
import 'package:x_station_app/core/style_font_manager/style_manager.dart';
import 'package:x_station_app/core/text_manager/text_manager.dart';
import 'package:x_station_app/view/screens/Posting/Posting_widgett/Posting_Form/Posting_form.dart';

class PostingWidget extends StatelessWidget {
  const PostingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: const Color(0Xff63628C),
          ),
          child: SizedBox(
            height: 114.h,
            width: 360.w,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 43),
                  child: SvgPicture.asset(
                    AssetsImage.arrowLeft,
                    width: 6.w,
                    height: 12.h,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 74),
                  child: Text(
                    TextManager.posting,
                    style: TextStyleManager.textStyle32ow800,
                  ),
                ),
              ],
            ),
          ),
        ),
        const PostingForm(),
        SizedBox(
          height: 43.h,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 197),
          child: Container(
            height: 50.h,
            width: 150.w,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40),
                color: const Color(0Xff63628C)),
            child: Center(
              child: Text(
                TextManager.postnow,
                style: TextStyleManager.textStyleRopotow600,
              ),
            ),
          ),
        )
      ],
    );
  }
}
