import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:x_station_app/core/assets_manager/assets_manager.dart';
import 'package:x_station_app/core/style_font_manager/style_manager.dart';
import 'package:x_station_app/core/text_manager/text_manager.dart';

class PostingForm extends StatelessWidget {
  const PostingForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 131, top: 46),
          child: Text(
            TextManager.type,
            style: TextStyleManager.textStyleRopotow400,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 16, top: 22),
          child: SizedBox(
            width: 325.w,
            height: 204.h,
            child: TextFormField(
              maxLines: 9,
              style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w400),
              decoration: const InputDecoration(
                  // border: InputBorder.none,
                  filled: true,
                  fillColor: Color(0Xffcfcedb),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20)))),
            ),
          ),
        ),
        SizedBox(
          height: 32.h,
        ),
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: const Color(0XffD9D9D9),
            ),
            child: Container(
              height: 226.h,
              width: 307.w,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SvgPicture.asset(
                    AssetsImage.Plus,
                    width: 90.w,
                    height: 90.h,
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    TextManager.Addattachment,
                    style: TextStyleManager.textStyle20w300,
                  ),
                ],
              ),
            ),
          ),
        )
      ],
    );
  }
}
